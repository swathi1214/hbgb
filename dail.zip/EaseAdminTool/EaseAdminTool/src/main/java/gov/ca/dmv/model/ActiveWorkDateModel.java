package gov.ca.dmv.model;

import java.util.Date;
import java.util.List;

public class ActiveWorkDateModel {
	
	private List<String> officeIds;
	private String selectedOfficeId;
	private Date workDate;
	private String techId;

	public List<String> getOfficeIds() {
		return officeIds;
	}

	public void setOfficeIds(List<String> officeIds) {
		this.officeIds = officeIds;
	}

	public String getSelectedOfficeId() {
		return selectedOfficeId;
	}

	public void setSelectedOfficeId(String selectedOfficeId) {
		this.selectedOfficeId = selectedOfficeId;
	}

	public Date getWorkDate() {
		return workDate;
	}

	public void setWorkDate(Date workDate) {
		this.workDate = workDate;
	}

	public String getTechId() {
		return techId;
	}

	public void setTechId(String techId) {
		this.techId = techId;
	}
	

}

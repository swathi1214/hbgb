package gov.ca.dmv.DAO;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import gov.ca.dmv.domain.Vtdm028uOfficeWrkDtCntrl;

@Repository
public class ActiveWorkDateDAO {

	@Autowired
	private EntityManager entityManager;
	
	@SuppressWarnings("unchecked")
	public List<Vtdm028uOfficeWrkDtCntrl> getOfficeWrkDtControlByOfficeIdAndWorkDate(int officeId, String officeWorkDate){
		return entityManager.createQuery("from Vtdm028uOfficeWrkDtCntrl owdc where owdc.vssm028uOffice.officeId = :officeId and owdc.createTstamp = :officeWorkDate")
		.setParameter("officeId", officeId)
		.setParameter("officeWorkDate", officeWorkDate).getResultList();
	}

	@SuppressWarnings("unchecked")
	public List<Integer> getAllOfficeIds() {
		// TODO Auto-generated method stub
		return entityManager.createQuery("select officeId from Vssm028uOffice").getResultList();
	}
	
	
}

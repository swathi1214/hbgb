package gov.ca.dmv.controller;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import gov.ca.dmv.domain.Vtdm028uOfficeWrkDtCntrl;
import gov.ca.dmv.model.ActiveWorkDateModel;
import gov.ca.dmv.service.ActiveWorkDateService;

@Controller
@RequestMapping("/activeWorkDate")
public class ActiveWorkDateController {

	@Autowired
	private ActiveWorkDateService activeWorkDateService;
	
	@RequestMapping("/view")
	public String view(@ModelAttribute("model") ActiveWorkDateModel activeWorkDateModel) throws Exception {
		activeWorkDateModel.setOfficeIds(activeWorkDateService.getAllOfficeIds());
		activeWorkDateModel.setWorkDate(Calendar.getInstance().getTime());
		return "activateWorkDate";
	}
	
	
	@RequestMapping("/search")
	public String search(@ModelAttribute("model") ActiveWorkDateModel activeWorkDateModel) throws Exception {
		activeWorkDateModel.setOfficeIds(activeWorkDateService.getAllOfficeIds());
		if(StringUtils.isEmpty(activeWorkDateModel.getTechId())) {
		activeWorkDateModel.setCriteria1Results(activeWorkDateService.getOfficeWrkDtControlByOfficeIdAndWorkDate(activeWorkDateModel.getSelectedOfficeId(), activeWorkDateModel.getWorkDate()));
		}else {
			List<Vtdm028uOfficeWrkDtCntrl> criteria1Results = activeWorkDateService.getOfficeWrkDtControlByOfficeIdAndWorkDate(activeWorkDateModel.getSelectedOfficeId(), activeWorkDateModel.getWorkDate());
			if(CollectionUtils.isEmpty(criteria1Results) && criteria1Results.size() > 1) {
				activeWorkDateModel.setCriteria1Results(activeWorkDateService.getOfficeWrkDtControlByOfficeIdAndWorkDate(activeWorkDateModel.getSelectedOfficeId(), activeWorkDateModel.getWorkDate()));
			}
			activeWorkDateModel.setCriteria2Results(activeWorkDateService.getEmpWrkDateControlByOfficeIdWorkDateTechId(activeWorkDateModel.getSelectedOfficeId(), activeWorkDateModel.getWorkDate(), activeWorkDateModel.getTechId()));
		}
		return "activateWorkDate";
	}
	
	@InitBinder
	public void initBinder(WebDataBinder binder) {
	    SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy");
	    sdf.setLenient(true);
	    binder.registerCustomEditor(Date.class, new CustomDateEditor(sdf, true));
	}
	
}

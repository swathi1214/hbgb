package gov.ca.dmv.DAO;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import gov.ca.dmv.domain.Vtdm027uEmpWrkDtCntrl;
import gov.ca.dmv.domain.Vtdm028uOfficeWrkDtCntrl;

@Repository
public class ActiveWorkDateDAO {

	@Autowired
	private EntityManager entityManager;
	
	@SuppressWarnings("unchecked")
	public List<Vtdm028uOfficeWrkDtCntrl> getOfficeWrkDtControlByOfficeIdAndWorkDate(String officeId, Date workDate) throws Exception{
		List<Vtdm028uOfficeWrkDtCntrl>  res = entityManager.createQuery("from Vtdm028uOfficeWrkDtCntrl owdc where owdc.vssm028uOffice.officeId = :officeId and owdc.authdWrkDt < :officeWorkDate")
		.setParameter("officeId", officeId)
		.setParameter("officeWorkDate", workDate)
		.getResultList();
		return res;
	}

	@SuppressWarnings("unchecked")
	public List<String> getAllOfficeIds() {
		// TODO Auto-generated method stub
		return entityManager.createQuery("select distinct officeId from Vssm028uOffice").getResultList();
	}

	@SuppressWarnings("unchecked")
	public List<Vtdm027uEmpWrkDtCntrl> getEmpWrkDateControlByOfficeIdWorkDateTechId(String officeId,
			Date workDate, String techId) {
		Session session = entityManager.unwrap(Session.class);
		return session.createQuery("from Vtdm027uEmpWrkDtCntrl ewdc where ewdc.officeWrkDtCntrl.vssm028uOffice.officeId = :officeId and ewdc.officeWrkDtCntrl.authdWrkDt < :officeWorkDate and ewdc.vssm026uEmployee.techId = :techId")
		.setParameter("officeId", officeId)
		.setParameter("officeWorkDate", workDate)
		.setParameter("techId", techId)
		.list();
	}
	
	
}

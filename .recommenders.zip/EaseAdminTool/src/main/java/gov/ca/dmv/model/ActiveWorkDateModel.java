package gov.ca.dmv.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import gov.ca.dmv.domain.Vtdm027uEmpWrkDtCntrl;
import gov.ca.dmv.domain.Vtdm028uOfficeWrkDtCntrl;

public class ActiveWorkDateModel {
	
	private List<String> officeIds;
	private String selectedOfficeId;
	private Date workDate;
	private String techId;
	private List<Vtdm028uOfficeWrkDtCntrl> criteria1Results = new ArrayList<Vtdm028uOfficeWrkDtCntrl>();
	private List<Vtdm027uEmpWrkDtCntrl> criteria2Results = new ArrayList<Vtdm027uEmpWrkDtCntrl>();

	public List<String> getOfficeIds() {
		return officeIds;
	}

	public void setOfficeIds(List<String> officeIds) {
		this.officeIds = officeIds;
	}

	public String getSelectedOfficeId() {
		return selectedOfficeId;
	}

	public void setSelectedOfficeId(String selectedOfficeId) {
		this.selectedOfficeId = selectedOfficeId;
	}

	public Date getWorkDate() {
		return workDate;
	}

	public void setWorkDate(Date workDate) {
		this.workDate = workDate;
	}

	public String getTechId() {
		return techId;
	}

	public void setTechId(String techId) {
		this.techId = techId;
	}

	public List<Vtdm028uOfficeWrkDtCntrl> getCriteria1Results() {
		return criteria1Results;
	}

	public void setCriteria1Results(List<Vtdm028uOfficeWrkDtCntrl> criteria1Results) {
		this.criteria1Results = criteria1Results;
	}

	public List<Vtdm027uEmpWrkDtCntrl> getCriteria2Results() {
		return criteria2Results;
	}

	public void setCriteria2Results(List<Vtdm027uEmpWrkDtCntrl> criteria2Results) {
		this.criteria2Results = criteria2Results;
	}
	

}

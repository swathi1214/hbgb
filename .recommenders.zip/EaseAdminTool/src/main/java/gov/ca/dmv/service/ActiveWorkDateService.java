package gov.ca.dmv.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import gov.ca.dmv.DAO.ActiveWorkDateDAO;
import gov.ca.dmv.domain.Vtdm027uEmpWrkDtCntrl;
import gov.ca.dmv.domain.Vtdm028uOfficeWrkDtCntrl;

@Service
public class ActiveWorkDateService {
	
	@Autowired
	private ActiveWorkDateDAO activeWorkDateDAO;
	
	@Transactional(readOnly = true)
	public List<Vtdm028uOfficeWrkDtCntrl> getOfficeWrkDtControlByOfficeIdAndWorkDate(String officeId, Date workDate) throws Exception{
		return activeWorkDateDAO.getOfficeWrkDtControlByOfficeIdAndWorkDate(officeId, workDate);
		
	}
	
	@Transactional(readOnly = true)
	public List<String> getAllOfficeIds(){
		return activeWorkDateDAO.getAllOfficeIds();
	}

	@Transactional(readOnly = true)
	public List<Vtdm027uEmpWrkDtCntrl> getEmpWrkDateControlByOfficeIdWorkDateTechId(String selectedOfficeId,
			Date workDate, String techId) {
return activeWorkDateDAO.getEmpWrkDateControlByOfficeIdWorkDateTechId(selectedOfficeId,workDate,techId);
	}

}

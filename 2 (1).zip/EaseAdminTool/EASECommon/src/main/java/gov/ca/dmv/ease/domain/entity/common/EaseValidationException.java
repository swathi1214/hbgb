/**
 * 
 */
package gov.ca.dmv.ease.domain.entity.common;

/**
 * Description: I am generic validation exception
 * File: EaseValidationException.java
 * Module:  gov.ca.dmv.ease.fw.exception.impl
 * Created: Aug 3, 2009   
 * @author MWPXP2  
 * @version $Revision: 1.1 $
 * Last Changed: $Date: 2012/10/01 02:57:15 $
 * Last Changed By: $Author: mwpxp2 $
 */
public class EaseValidationException extends EaseConstraintException {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -5456930762639031675L;

	/**
	 * Instantiates a new ease validation exception.
	 */
	public EaseValidationException() {
		super();
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 */
	public EaseValidationException(String message) {
		super(message);
	}

	/**
	 * The Constructor.
	 * 
	 * @param message the message
	 * @param cause the cause
	 */
	public EaseValidationException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * The Constructor.
	 * 
	 * @param cause the cause
	 */
	public EaseValidationException(Throwable cause) {
		super(cause);
	}
}
/**
 *  Modification History:
 *
 *  $Log: EaseValidationException.java,v $
 *  Revision 1.1  2012/10/01 02:57:15  mwpxp2
 *  Initial - split from the obsoleted EASEArchitecture tagged PRE_INTEGRATION_SPLIT_120930 into WS5-compatible project organizations
 *
 *  Revision 1.2  2010/03/23 20:32:24  mwpxp2
 *  Comment/inheritance mods
 *
 *  Revision 1.1  2009/11/23 16:22:53  mwrsk
 *  Intial commit
 *
 *  Revision 1.2  2009/10/23 17:20:48  mwpxp2
 *  Re-created javadoc to fix obsolete references
 *
 *  Revision 1.1  2009/10/03 20:20:42  mwpxp2
 *  Moved into fw.exception.impl; bulk cleanup
 *
 *  Revision 1.2  2009/09/29 22:01:07  mwpxp2
 *  Removed obsolete to do
 *
 *  Revision 1.1  2009/08/27 02:24:37  mwsmg6
 *  moved framework-related classes to the Framework project
 *
 *  Revision 1.2  2009/08/17 21:02:30  mwpxp2
 *  Added javadoc
 *
 *  Revision 1.1  2009/08/04 01:36:22  mwpxp2
 *  Initial
 *
 */
